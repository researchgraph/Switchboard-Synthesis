Placeholder for Neo4j logs
