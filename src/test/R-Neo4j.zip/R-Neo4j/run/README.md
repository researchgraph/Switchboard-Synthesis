This folder is required for Neo4j at runtime
